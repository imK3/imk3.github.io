from flask import Flask, render_template, request, redirect, session
from hashlib import md5
import yaml
import zipfile
import tarfile
import os
import re


app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get('SECRET_KEY')


def extractFile(filepath, type):

    extractdir = filepath.split('.')[0]
    if not os.path.exists(extractdir):
        os.makedirs(extractdir)

    if type == 'tar':
        tf = tarfile.TarFile(filepath)
        tf.extractall(extractdir)
        return tf.getnames()

    if type == 'zip':
        zf = zipfile.ZipFile(filepath, 'r')
        zf.extractall(extractdir)
        return zf.namelist()


@app.route('/', methods=['GET'])
def main():
    if not session.get('user'):
        return redirect('/login')
    else:
        fn = 'uploads/' + md5(session.get('user').encode()).hexdigest()
        session['fn'] = fn
        if not os.path.exists(fn):
            os.makedirs(fn)
        return render_template('index.html')


@app.route('/upload', methods=['GET', 'POST'])
def upload():

    if request.method == 'GET':
        return redirect('/')

    if request.method == 'POST':
        upFile = request.files['file']

        if re.search(r"\.\.|/", upFile.filename, re.M|re.I) != None:
            return "<script>alert('Hacker!');window.location.href='/upload'</script>"

        savePath = f"{session['fn']}/{upFile.filename}"

        upFile.save(savePath)

        if tarfile.is_tarfile(savePath):
            zipDatas = extractFile(savePath, 'tar')
            return render_template('result.html', path=savePath, files=zipDatas)
        elif zipfile.is_zipfile(savePath):
            tarDatas = extractFile(savePath, 'zip')
            return render_template('result.html', path=savePath, files=tarDatas)
        else:
            return f"<script>alert('{upFile.filename} upload successfully');history.back(-1);</script>"


@app.route('/login', methods=['GET', 'POST'])
def login():
    with open('config/userConfig.yaml', 'w') as f:
        data = {'user': 'Admin', 'host': '127.0.0.1', 'info': 'System super administrator and super user.'}
        f.write(yaml.dump(data))

    if request.method == 'GET':
        return render_template('login.html')

    if request.method == 'POST':
        username = request.form.get('username')
        if username and username == "Admin":
            with open('config/userConfig.yaml', 'rb') as f:
                userConfig = yaml.load(f.read())
                if userConfig['host'] == request.remote_addr:
                    session['user'] = userConfig['user']
                    return render_template('admin.html', username=userConfig['user'], message=userConfig['info'])
                else:
                    return "<script>alert('Can only login locally');history.back(-1);</script>"
        elif username:
            session['user'] = username
            return redirect('/')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)